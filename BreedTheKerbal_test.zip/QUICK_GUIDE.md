# BreedTheKerbal — Quick Guide

## Requirements
- KSP 1.x (tested on 1.12)
- No external dependencies — vanilla KSP only

## Installation
1. Copy `BreedTheKerbal.dll` and `BreedTheKerbal.cfg` into `GameData/BreedTheKerbal/`
2. Done — the **Colony Manager** button appears in the toolbar

---

## Getting Started

**Vessel requirements:**
- A part with crew capacity >= 4
- Science Lab
- One adult male + one adult female (not pregnant, not postpartum)
- >= 1 free seat

**Manual pairing** (default):
Colony Manager -> select a pair -> **Start Pregnancy**

**Automatic:**
Set `AutoBreeding = true` in `BreedTheKerbal.cfg`

---

## Life Stages

Birth -> Newborn (50 days) -> Child (100 days) -> Teenager (150 days) -> Adult

*(1 Kerbin day = 6 h real time)*

| Stage | EVA | Lab / Harvester | Pilot |
|---|---|---|---|
| Newborn | No | 0% | 0 stars |
| Child | No | 25% | 0 stars |
| Teenager (with caretaker) | Yes | 50% | 0 stars |
| Teenager (no caretaker) | No | 20% | 0 stars |
| Pregnant - 1st half | Yes | 100% | full |
| Pregnant - 2nd half | No | 40% | level 1 |
| Postpartum (10 days) | No | 0% | -- |

---

## Caretaker

Newborns and Children **must have an adult** on the same vessel.

| Stage | Without caretaker |
|---|---|
| Newborn | death after **5 days** |
| Child | death after **15 days** |
| Teenager | efficiency drops to 20%, EVA blocked |

A red bar and countdown in Colony Manager show time remaining until death.

---

## Career Mode - Daily Upkeep

| Stage | Cost / day |
|---|---|
| Newborn | 150 funds |
| Child | 100 funds |
| Teenager | 50 funds |

Insufficient funds -> **LOW SUPPORT** -> Child 20%, Teenager 35%

---

## Colony Manager

- Hover over a **Kerbal name** -> tooltip with status, active penalty and countdown
- Hover over **LOW SUPPORT** -> breakdown of the funding shortfall

---

## Configuration (BreedTheKerbal.cfg)

Edit and restart KSP - no recompile needed.
All durations in Kerbin seconds (1 day = 21 600 s).

---

## Debug Shortcuts (Debug build only)

| Shortcut | Action |
|---|---|
| Alt + Shift + B | Print all Kerbal life-stage statuses to screen |
| Alt + Shift + N | Advance all non-adults one stage forward |
